import React, { useEffect, useState } from 'react';
import axios from 'axios';

function App() {
  const [vehiculos, setVehiculos] = useState([]);
  const [productos, setProductos] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:4545/api/vehiculos')
      .then((response) => setVehiculos(response.data))
      .catch((error) => console.error(error));

    axios.get('http://localhost:4545/api/productos')
      .then((response) => setProductos(response.data))
      .catch((error) => console.error(error));
  }, []);

  return (
    <div className="container mt-5">
      <h1 className="display-4">Vehículos</h1>
      <ul className="list-group">
        {vehiculos.map((vehiculo) => (
          <li key={vehiculo.id} className="list-group-item">{vehiculo.marca}</li>
        ))}
      </ul>

      <h1 className="display-4 mt-4">Productos</h1>
      <ul className="list-group">
        {productos.map((producto) => (
          <li key={producto.id} className="list-group-item">{producto.nombre}</li>
        ))}
      </ul>
    </div>
  );
}

export default App;


